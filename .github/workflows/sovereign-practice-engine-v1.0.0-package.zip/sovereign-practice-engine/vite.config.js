import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Relative base ("./") so the built app works from any subpath —
// a GitHub Pages project site (username.github.io/repo-name/), a
// custom domain root, or a local file preview — with no extra config.
export default defineConfig({
  plugins: [react()],
  base: "./",
  build: {
    outDir: "dist",
    assetsDir: "assets",
    chunkSizeWarningLimit: 1200, // App.jsx embeds the source imagery as base64; this is expected.
  },
});
