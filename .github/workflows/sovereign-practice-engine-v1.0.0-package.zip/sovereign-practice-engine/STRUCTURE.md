# Project Structure & Version

## Version

**1.0.0** — first publication-ready package. See `ACCEPTANCE.md` for what
that status does and doesn't cover.

## File map

```
sovereign-practice-engine/
├── VERSION.txt               Canonical version marker — resolves any version ambiguity
├── README.md                 Overview, what's in the package, storage shim explanation
├── INSTALL.md                npm install / dev / build / preview commands
├── DEPLOY.md                 GitHub Pages / Netlify / Vercel / PWA install instructions
├── ACCEPTANCE.md             Final publication audit, category by category
├── KNOWN_LIMITATIONS.md      Limitations + deferred future enhancements
├── STRUCTURE.md              This file
├── HANDOFF.md                Final handoff report (version, build/test results, verdict)
├── package.json              4 dependencies total: react, react-dom, vite, @vitejs/plugin-react
├── vite.config.js            Relative base ("./") for portable static hosting
├── index.html                App shell, PWA meta tags, manifest/icon links
├── src/
│   ├── App.jsx                The application: UI, lunar engine, all spiritual
│   │                           content, all 9 source images (base64), ~2,060 lines
│   └── main.jsx                Entry point + window.storage → localStorage shim
└── public/
    ├── manifest.json          PWA manifest
    ├── service-worker.js      Offline app-shell caching (see file for notification-scope notes)
    └── icons/
        ├── icon-192.png
        ├── icon-512.png
        └── icon-512-maskable.png
```

No other source files exist. No test files, debug scaffolding, or
duplicate/obsolete versions are included in this package — those stayed in
the working environment and were not copied in.
