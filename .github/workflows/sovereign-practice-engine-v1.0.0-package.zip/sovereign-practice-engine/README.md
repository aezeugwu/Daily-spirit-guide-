# Sovereign Practice Engine

A private, offline-first daily spiritual practice system built around your
own source material — the runes (Algiz, Uruz, Jera), the seven Tarot cards,
the Sovereign Manifestor's Decree, the guided meditation, and the 60-Second
Reset — organized by the actual astronomical lunar cycle rather than the
calendar month.

This is not a generic meditation app, habit tracker, or spiritual library.
It is a single-user guidance system: open it, and it tells you exactly what
to do next — Morning, Midday, or Evening — walks you through it step by
step, and remembers your practice history, your cycle intentions, and your
private journal, entirely on your own device.

---

## What's actually in this package

| Piece | What it is |
|---|---|
| `src/App.jsx` | The entire application — UI, lunar engine, all spiritual content, and all 9 source images embedded as compressed base64 — one component, ~2,060 lines. |
| `src/main.jsx` | Entry point. Mounts the app and provides a `window.storage` shim backed by `localStorage` (see below). |
| `index.html` | App shell, PWA meta tags, manifest/icon links. |
| `vite.config.js` | Minimal Vite config with a relative (`./`) base so the build works from any subpath (GitHub Pages project site, custom domain, etc.) with zero extra config. |
| `public/manifest.json` | PWA manifest — name, icons, standalone display mode, navy theme color. |
| `public/service-worker.js` | Offline app-shell caching. Documents in its own comments exactly why it does **not** attempt background push notifications, and what that would actually require. |
| `public/icons/` | App icons generated from your Magician image (192px, 512px, and a padded 512px maskable variant for Android's adaptive-icon safe zone). |
| `package.json` | Two dependencies: `react`, `react-dom`. Two dev dependencies: `vite`, `@vitejs/plugin-react`. Nothing else. |

No accounts, no analytics, no backend, no external database. Everything
above is the entire application.

## Why a `window.storage` shim?

This app was originally built and validated inside Claude.ai's artifact
runtime, which provides a built-in private key/value store called
`window.storage` (`get` / `set` / `delete` / `list`). Rather than rewrite
the storage calls for standalone deployment, `src/main.jsx` detects that
`window.storage` doesn't exist outside that runtime and installs a shim
with the exact same four methods, backed by the browser's own
`localStorage`. **No application code in `App.jsx` had to change.** This
was verified directly: the shim was bundled and run in a real browser,
writing and reading real `localStorage` under the `spe:local:` prefix.

---

See `INSTALL.md` for setup, `DEPLOY.md` for publishing it, and
`ACCEPTANCE.md` for exactly what has and hasn't been verified.
