# Install & Build

## Requirements

- Node.js 18+ and npm (any recent LTS is fine)
- A normal internet connection during `npm install` (this project's own
  build environment had no network access, so this step has not been run —
  see `ACCEPTANCE.md`, section J)

## 1. Install dependencies

```bash
cd sovereign-practice-engine
npm install
```

This installs exactly four packages: `react`, `react-dom` (runtime) and
`vite`, `@vitejs/plugin-react` (build tooling).

## 2. Run it locally

```bash
npm run dev
```

Vite will print a local URL (typically `http://localhost:5173`). Open it
on your phone's browser (same Wi-Fi network, use your computer's LAN IP
instead of `localhost`) to test on the actual target device.

## 3. Production build

```bash
npm run build
```

Output goes to `dist/`. This is a static site — every file in `dist/` is
plain HTML/JS/CSS/PNG, and can be hosted anywhere that serves static files.

## 4. Preview the production build locally

```bash
npm run preview
```

Serves the built `dist/` folder locally so you can sanity-check it before
deploying — this is the closest thing to "what will actually ship."

---

If any of these three commands fail, stop before deploying and share the
exact error — don't deploy a build that didn't complete cleanly.
