/* Sovereign Practice Engine — service worker
 *
 * WHAT THIS DOES:
 * Caches the app shell (HTML/JS/CSS/icons) on first load so the app opens
 * and works offline afterward — required content (runes, tarot, decree,
 * meditation script, all 9 images) is already embedded directly in the
 * JS bundle, so once cached, the entire practice experience works with
 * no network connection at all.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO:
 * Fire push notifications. A service worker CAN receive and display a
 * push notification via the Push API — but only if a server sends one.
 * That requires:
 *   1. A backend that stores a per-device push subscription and holds
 *      VAPID keys, and
 *   2. That backend actually calling the Push service at the scheduled
 *      reminder times (morning / midday / evening).
 * Neither exists here, on purpose — this app has no backend by design
 * (per the brief: no accounts, no server, local-first, private). The
 * in-app Reminders screen stores your preferred times locally and will
 * fire a local notification via the Notification API *while the app is
 * open*, but cannot wake your phone when the app is closed. If reliable
 * closed-app reminders matter more than staying fully local/serverless,
 * the honest options are: (a) use your phone's own OS reminder/alarm
 * app alongside this one, pointed at your chosen practice times, or
 * (b) add a small backend later specifically for scheduled push. That's
 * a deliberate, documented scope boundary, not an oversight.
 */

const CACHE_NAME = "sovereign-practice-v1";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

// Cache-first for the app shell; network-first fallback for everything else,
// falling back to cache when offline.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return response;
        })
        .catch(() => cached);
    })
  );
});
