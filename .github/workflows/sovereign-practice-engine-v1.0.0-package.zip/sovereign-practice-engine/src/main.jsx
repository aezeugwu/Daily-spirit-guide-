import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

/* ------------------------------------------------------------
   window.storage shim
   ------------------------------------------------------------
   The Sovereign Practice Engine was built and validated inside
   Claude.ai's artifact runtime, which provides a built-in
   `window.storage` key/value API (get/set/delete/list) for
   private, per-user persistence.

   Outside that runtime — i.e. once this is deployed as its own
   site — that API doesn't exist, so this shim implements the
   same four methods on top of the browser's own localStorage.
   No app code had to change: App.jsx calls window.storage exactly
   the way it did inside Claude.ai.
------------------------------------------------------------- */
if (!window.storage) {
  const PREFIX = "spe:local:";
  window.storage = {
    async get(key) {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw === null) throw new Error("not found");
      return { key, value: raw, shared: false };
    },
    async set(key, value) {
      localStorage.setItem(PREFIX + key, value);
      return { key, value, shared: false };
    },
    async delete(key) {
      localStorage.removeItem(PREFIX + key);
      return { key, deleted: true, shared: false };
    },
    async list(prefix) {
      const keys = Object.keys(localStorage)
        .filter(k => k.startsWith(PREFIX))
        .map(k => k.slice(PREFIX.length))
        .filter(k => !prefix || k.startsWith(prefix));
      return { keys };
    },
  };
}

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {
      /* offline caching is a nice-to-have, not required for the app to run */
    });
  });
}

createRoot(document.getElementById("root")).render(<App />);
