# Known Limitations & Future Enhancements

## Known limitations (present by design or by environment, not oversights)

1. **No background push notifications.** The Reminders screen stores your
   preferred times and can fire a notification while the app is open, but
   cannot wake a closed app. See `public/service-worker.js` for the full
   technical explanation of what this would require (a backend holding
   VAPID keys and push subscriptions).
2. **Lunar calculation is astronomically approximate**, not exact —
   accurate to roughly an hour, using a truncated Meeus algorithm rather
   than a full ephemeris. Stated plainly in-app rather than implied as
   exact.
3. **Production build (`npm run build`) has not been executed** in the
   environment this package was assembled in, due to no outbound network
   access for `npm install`. See `ACCEPTANCE.md` section J for exactly
   what was verified as a substitute, and run the real build before
   deploying.
4. **Secondary touch targets remain compact.** Status pills, filter chips,
   and bottom-nav labels are 29–36px — smaller than the 44–48dp ideal —
   by a deliberate density/aesthetic tradeoff on secondary (not primary)
   actions.
5. **Birth date is stored but unused.** Captured in Settings for possible
   future personalized-calendar features; no astrological logic is applied
   to it currently, and none should be added without your explicit content
   direction (per the "don't invent spiritual content silently" rule this
   project has followed throughout).
6. **The 8-phase lunar "focus" content (why/action/reflection per moon
   phase) is application-design material**, not verbatim from your
   original source document — your document didn't specify per-phase daily
   practices. It's kept structurally separate in the code from the
   verbatim source content (runes, tarot, decree, meditation, morning/
   reset/evening prompts). If you have your own material for this, it can
   be swapped in directly.

## Future enhancements (not built, deliberately deferred)

- **True background reminders**, via a small backend (VAPID push keys +
  a subscription store) — only worth adding if in-app reminders prove
  insufficient in daily use.
- **Real Vite production build verification**, in a normal Node/npm
  environment with network access — see `INSTALL.md`.
- **Separate image assets instead of embedded base64**, if the single-file
  bundle size ever becomes a real problem — trades a larger initial JS
  parse for better long-term caching. Not currently a proven need.
