# Deploy & Install as an App

## Deploying (any static host)

After `npm run build`, the `dist/` folder is a complete static site. Upload
its contents to any static host. Three concrete options:

### Option A — GitHub Pages, fully automated (recommended for phone-only use)

This repo includes `.github/workflows/deploy.yml`, which builds the app
**inside GitHub's own cloud servers** — no local Node, npm, or laptop
required on your end. This is also what finally closes the one
verification gap noted in `ACCEPTANCE.md`: the real `npm install && npm
run build` will actually execute, in GitHub's environment, and you'll be
able to see whether it succeeded.

1. Create a new GitHub repository (via github.com or the GitHub app — no computer needed).
2. Upload every file and folder from this package into the repo, preserving the folder structure exactly as it is here (see `STRUCTURE.md`). On the GitHub website you can drag-and-drop a whole folder structure via "Add file → Upload files."
3. In the repo, go to **Settings → Pages**, and under "Build and deployment," set **Source** to **GitHub Actions**.
4. Go to the **Actions** tab. The workflow ("Build and deploy to GitHub Pages") should already be running — it runs automatically on every push to `main`, and can also be re-run manually from that tab.
5. If it finishes with a green checkmark, your app is live. GitHub shows the URL both on the Actions run page and under Settings → Pages — typically `https://<username>.github.io/<repo-name>/`.
6. If it fails, open the failed run and read the log — it will show exactly which step failed (most likely `npm install` or `npm run build`), which is the real, first-time execution of the one step this project's own build environment couldn't run.

### Option B — GitHub Pages, manual (needs a computer)

1. Push this project to a GitHub repo.
2. In the repo, add a GitHub Actions workflow that runs `npm install && npm run build` and publishes `dist/` to the `gh-pages` branch — or, more simply, build locally and push the contents of `dist/` directly to a `gh-pages` branch.
3. In the repo Settings → Pages, set the source to the `gh-pages` branch.
4. Your app will be live at `https://<username>.github.io/<repo-name>/`.

Because `vite.config.js` uses a relative base (`./`), this works at that
subpath with no configuration changes — the same setup that lets a build
work from a custom domain root also works from a GitHub Pages project path.

### Option B — Netlify / Vercel

Connect the repo, set build command `npm run build`, publish directory
`dist`. Both platforms auto-detect Vite projects and will typically fill
these in for you.

### Option C — Any static file server

Copy `dist/` anywhere that serves static files over HTTPS. HTTPS is not
optional — service workers (used for offline caching) and the
`Notification` API both require a secure context, except on `localhost`.

---

## Installing on Android (PWA)

Once deployed to an HTTPS URL:

1. Open the URL in Chrome on your Android phone.
2. Tap the **⋮** menu → **Add to Home screen** (Chrome may also prompt this automatically after a visit or two).
3. Confirm. The Sovereign Practice Engine icon (from `public/icons/`) appears on your home screen and opens full-screen, without browser chrome, using the navy/gold identity from `manifest.json`.

## Installing on iPhone (PWA)

1. Open the URL in Safari (must be Safari, not Chrome, for this step on iOS).
2. Tap the Share icon → **Add to Home Screen**.
3. Confirm.

## After installing

The first visit caches the app shell for offline use (see
`public/service-worker.js`). Because every piece of spiritual content —
runes, tarot, decree, meditation script, and all 9 images — is embedded
directly in the JavaScript bundle rather than fetched separately, the
entire practice experience works offline after that first load, not just
the shell.
